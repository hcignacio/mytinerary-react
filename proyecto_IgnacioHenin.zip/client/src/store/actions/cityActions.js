export const CITY_ACTION = 'CITY_ACTION';

export const getAction = () => {
 
      return {
        type: CITY_ACTION,
        payload: []
      }
};
export const CityAction = async (dispatch) => {
  dispatch(await fetch('/cities')
    .then(response =>
      response.json())
    .then(cities => {
      console.log("cities", cities);
      return {
        type: CITY_ACTION,
        payload: cities
      };
    })
  )
  /* return {
    type 
  }; */
};
