import { CITY_ACTION } from '../actions/cityActions'

const defaultState = [
  { id: 1, nombre: 'Barcelona' }
];

function cityReducer(state = defaultState, action) {
  console.log(action);

  switch (action.type) {
    case CITY_ACTION: {
      console.log("action", action.payload);

      return {
        ...state,
        cities: [...state.cities, action.payload]
      }
    }
    default:
      return state;
  }
}

export default cityReducer;